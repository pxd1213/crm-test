import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Checkbox } from './ui/checkbox';
import { Separator } from './ui/separator';
import { Search, Filter, ChevronDown, CalendarIcon, X, Eye, MessageCircle } from 'lucide-react';
import { format } from 'date-fns';

interface SearchResult {
  id: string;
  type: 'case' | 'message' | 'user';
  title: string;
  description: string;
  status?: string;
  priority?: string;
  assignedTo?: string;
  createdAt: string;
  relevanceScore: number;
}

const mockSearchResults: SearchResult[] = [
  {
    id: 'CRM-445',
    type: 'case',
    title: 'Login Issues with Mobile App',
    description: 'Users reporting difficulty logging into the mobile application.',
    status: 'New',
    priority: 'High',
    assignedTo: 'Unassigned',
    createdAt: '2025-06-11T10:30:00Z',
    relevanceScore: 95
  },
  {
    id: 'CRM-444',
    type: 'case',
    title: 'Payment Processing Error',
    description: 'Credit card transactions failing intermittently.',
    status: 'In Progress',
    priority: 'Critical',
    assignedTo: 'Sarah Johnson',
    createdAt: '2025-06-10T14:15:00Z',
    relevanceScore: 88
  },
  {
    id: 'MSG-001',
    type: 'message',
    title: 'Payment gateway returning error code 500',
    description: 'Message from Jane Smith in case CRM-444',
    createdAt: '2025-06-10T14:15:00Z',
    relevanceScore: 82
  }
];

export function SearchFilter() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
  const [selectedPriorities, setSelectedPriorities] = useState<string[]>([]);
  const [selectedOperators, setSelectedOperators] = useState<string[]>([]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({});
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const operators = ['Sarah Johnson', 'Mike Chen', 'Emma Davis', 'Alex Rodriguez', 'Lisa Wang'];
  const statuses = ['New', 'In Progress', 'Resolved', 'Closed'];
  const priorities = ['Low', 'Medium', 'High', 'Critical'];
  const types = ['case', 'message', 'user'];

  const handleSearch = () => {
    setIsSearching(true);
    setTimeout(() => {
      let results = mockSearchResults;
      
      if (searchQuery) {
        results = results.filter(result => 
          result.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          result.description.toLowerCase().includes(searchQuery.toLowerCase())
        );
      }

      // Apply other filters...
      setSearchResults(results.sort((a, b) => b.relevanceScore - a.relevanceScore));
      setIsSearching(false);
    }, 500);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New': return 'bg-[#58a7af] text-white border-[#58a7af]';
      case 'In Progress': return 'bg-[#ff6515] text-white border-[#ff6515]';
      case 'Resolved': return 'bg-[#4d8f1e] text-white border-[#4d8f1e]';
      case 'Closed': return 'bg-[#989a9c] text-white border-[#989a9c]';
      default: return 'bg-[#989a9c] text-white border-[#989a9c]';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-500 text-white border-red-500';
      case 'High': return 'bg-orange-500 text-white border-orange-500';
      case 'Medium': return 'bg-yellow-500 text-white border-yellow-500';
      case 'Low': return 'bg-green-500 text-white border-green-500';
      default: return 'bg-[#989a9c] text-white border-[#989a9c]';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'case': return '📋';
      case 'message': return '💬';
      case 'user': return '👤';
      default: return '📄';
    }
  };

  const activeFiltersCount = selectedStatuses.length + selectedPriorities.length + 
    selectedOperators.length + selectedTypes.length + 
    (dateRange.from ? 1 : 0) + (dateRange.to ? 1 : 0);

  return (
    <div className="p-6 space-y-6 bg-[#f8f8f8] min-h-full">
      {/* Search Bar */}
      <Card className="bg-white border-[#cbcdce]">
        <CardContent className="pt-6">
          <div className="flex items-center space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[#989a9c]" />
              <Input
                placeholder="Search cases, messages, users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white border-[#cbcdce] text-[#1c1b1d]"
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
            <Button 
              onClick={handleSearch} 
              disabled={isSearching}
              className="bg-[#58a7af] hover:bg-[#4a9099] text-white border-0 font-medium"
            >
              {isSearching ? 'Searching...' : 'Search'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card className="bg-white border-[#cbcdce]">
        <Collapsible open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-[#f3f3f5] transition-colors">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2 text-[#625f66] font-bold">
                  <Filter className="h-5 w-5" />
                  <span>Filters</span>
                  {activeFiltersCount > 0 && (
                    <Badge className="bg-[#58a7af] text-white border-0">{activeFiltersCount}</Badge>
                  )}
                </CardTitle>
                <ChevronDown className={`h-4 w-4 transition-transform text-[#625f66] ${isFiltersOpen ? 'rotate-180' : ''}`} />
              </div>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Content Type */}
                <div>
                  <h4 className="font-medium mb-3 text-[#625f66]">Content Type</h4>
                  <div className="space-y-2">
                    {types.map((type) => (
                      <div key={type} className="flex items-center space-x-2">
                        <Checkbox
                          id={`type-${type}`}
                          checked={selectedTypes.includes(type)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedTypes([...selectedTypes, type]);
                            } else {
                              setSelectedTypes(selectedTypes.filter(t => t !== type));
                            }
                          }}
                          className="border-[#cbcdce] data-[state=checked]:bg-[#58a7af] data-[state=checked]:border-[#58a7af]"
                        />
                        <label htmlFor={`type-${type}`} className="text-sm capitalize cursor-pointer text-[#1c1b1d]">
                          {type}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Status */}
                <div>
                  <h4 className="font-medium mb-3 text-[#625f66]">Status</h4>
                  <div className="space-y-2">
                    {statuses.map((status) => (
                      <div key={status} className="flex items-center space-x-2">
                        <Checkbox
                          id={`status-${status}`}
                          checked={selectedStatuses.includes(status)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedStatuses([...selectedStatuses, status]);
                            } else {
                              setSelectedStatuses(selectedStatuses.filter(s => s !== status));
                            }
                          }}
                          className="border-[#cbcdce] data-[state=checked]:bg-[#58a7af] data-[state=checked]:border-[#58a7af]"
                        />
                        <label htmlFor={`status-${status}`} className="text-sm cursor-pointer text-[#1c1b1d]">
                          {status}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Priority */}
                <div>
                  <h4 className="font-medium mb-3 text-[#625f66]">Priority</h4>
                  <div className="space-y-2">
                    {priorities.map((priority) => (
                      <div key={priority} className="flex items-center space-x-2">
                        <Checkbox
                          id={`priority-${priority}`}
                          checked={selectedPriorities.includes(priority)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedPriorities([...selectedPriorities, priority]);
                            } else {
                              setSelectedPriorities(selectedPriorities.filter(p => p !== priority));
                            }
                          }}
                          className="border-[#cbcdce] data-[state=checked]:bg-[#58a7af] data-[state=checked]:border-[#58a7af]"
                        />
                        <label htmlFor={`priority-${priority}`} className="text-sm cursor-pointer text-[#1c1b1d]">
                          {priority}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Assigned Operator */}
                <div>
                  <h4 className="font-medium mb-3 text-[#625f66]">Assigned Operator</h4>
                  <div className="space-y-2">
                    {operators.map((operator) => (
                      <div key={operator} className="flex items-center space-x-2">
                        <Checkbox
                          id={`operator-${operator}`}
                          checked={selectedOperators.includes(operator)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedOperators([...selectedOperators, operator]);
                            } else {
                              setSelectedOperators(selectedOperators.filter(o => o !== operator));
                            }
                          }}
                          className="border-[#cbcdce] data-[state=checked]:bg-[#58a7af] data-[state=checked]:border-[#58a7af]"
                        />
                        <label htmlFor={`operator-${operator}`} className="text-sm cursor-pointer text-[#1c1b1d]">
                          {operator}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <Separator className="bg-[#cbcdce]" />

              <div className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSelectedStatuses([]);
                    setSelectedPriorities([]);
                    setSelectedOperators([]);
                    setSelectedTypes([]);
                    setDateRange({});
                  }} 
                  disabled={activeFiltersCount === 0}
                  className="border-[#cbcdce] text-[#625f66] bg-white hover:bg-[#f3f3f5]"
                >
                  <X className="mr-2 h-4 w-4" />
                  Clear Filters
                </Button>
                <Button 
                  onClick={handleSearch}
                  className="bg-[#58a7af] hover:bg-[#4a9099] text-white border-0"
                >
                  Apply Filters
                </Button>
              </div>
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <Card className="bg-white border-[#cbcdce]">
          <CardHeader>
            <CardTitle className="text-[#625f66] font-bold">Search Results ({searchResults.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {searchResults.map((result) => (
                <div key={result.id} className="border border-[#cbcdce] rounded-lg p-4 hover:bg-[#f3f3f5] transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-lg">{getTypeIcon(result.type)}</span>
                        <h3 className="font-medium text-[#625f66]">{result.title}</h3>
                        <Badge className="bg-[#989a9c] text-white border-0 capitalize">
                          {result.type}
                        </Badge>
                        {result.status && (
                          <Badge className={getStatusColor(result.status)}>
                            {result.status}
                          </Badge>
                        )}
                        {result.priority && (
                          <Badge className={getPriorityColor(result.priority)}>
                            {result.priority}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-[#989a9c] mb-2">
                        {result.description}
                      </p>
                      <div className="flex items-center space-x-4 text-xs text-[#989a9c]">
                        <span>ID: {result.id}</span>
                        {result.assignedTo && <span>Assigned: {result.assignedTo}</span>}
                        <span>Created: {new Date(result.createdAt).toLocaleDateString()}</span>
                        <span>Relevance: {result.relevanceScore}%</span>
                      </div>
                    </div>
                    <div className="flex space-x-2 ml-4">
                      <Button variant="ghost" size="sm" className="text-[#625f66] hover:text-[#58a7af] hover:bg-[#f3f3f5]">
                        <Eye className="h-4 w-4" />
                      </Button>
                      {result.type === 'case' && (
                        <Button variant="ghost" size="sm" className="text-[#625f66] hover:text-[#58a7af] hover:bg-[#f3f3f5]">
                          <MessageCircle className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {searchResults.length === 0 && searchQuery && !isSearching && (
        <Card className="bg-white border-[#cbcdce]">
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Search className="h-12 w-12 text-[#989a9c] mx-auto mb-4" />
              <h3 className="font-medium mb-2 text-[#625f66]">No results found</h3>
              <p className="text-sm text-[#989a9c]">
                Try adjusting your search query or filters
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}