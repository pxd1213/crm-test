import svgPaths from "./svg-7pxkwuafrm";
import imgImage38 from "figma:asset/7875ec06a79b275c7a497ae865e6549b9549e065.png";
import imgImage39 from "figma:asset/226e166f8b65bb74eb4ecf0ccbdbbe12b683a962.png";

function Group17() {
  return (
    <div
      className="absolute bottom-[2.36%] left-0 right-[2.302%] top-[1.964%]"
      data-name="Group-17"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 22 17"
      >
        <g id="Group-17">
          <path
            clipRule="evenodd"
            d={svgPaths.p8591580}
            fill="var(--fill-0, black)"
            fillRule="evenodd"
            id="Fill-11"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p24394a00}
            fill="var(--fill-0, #A0EF6E)"
            fillRule="evenodd"
            id="Fill-13"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p3cee700}
            fill="var(--fill-0, #A0EF6E)"
            fillRule="evenodd"
            id="Fill-15"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p1922b00}
            fill="var(--fill-0, #56BC2F)"
            fillRule="evenodd"
            id="Fill-16"
          />
        </g>
      </svg>
    </div>
  );
}

function EnverusEBlack() {
  return (
    <div
      className="h-[17.05px] overflow-clip relative shrink-0 w-[22px]"
      data-name="enverus E black"
    >
      <Group17 />
    </div>
  );
}

function Energylink() {
  return (
    <div className="h-4 relative shrink-0 w-[133.992px]" data-name="ENERGYLINK">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 134 16"
      >
        <g id="ENERGYLINK">
          <path d={svgPaths.p2aa5e00} fill="var(--fill-0, black)" id="Vector" />
          <path
            d={svgPaths.p2d842f00}
            fill="var(--fill-0, black)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p28df0b80}
            fill="var(--fill-0, black)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p1b29c900}
            fill="var(--fill-0, black)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p44a9100}
            fill="var(--fill-0, black)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p18767440}
            fill="var(--fill-0, black)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p20ffb280}
            fill="var(--fill-0, black)"
            id="Vector_7"
          />
          <path
            d={svgPaths.p10d7e100}
            fill="var(--fill-0, black)"
            id="Vector_8"
          />
          <path
            d={svgPaths.p207c0500}
            fill="var(--fill-0, black)"
            id="Vector_9"
          />
          <path
            d={svgPaths.p1570e100}
            fill="var(--fill-0, black)"
            id="Vector_10"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame15() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start p-0 relative">
        <EnverusEBlack />
        <div className="h-7 relative shrink-0 w-px" data-name="Vector">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 1 28"
          >
            <path d="M1 0H0V28H1V0Z" fill="var(--fill-0, black)" id="Vector" />
          </svg>
        </div>
        <Energylink />
      </div>
    </div>
  );
}

function Frame2149() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative">
        <Frame15 />
      </div>
    </div>
  );
}

function Frame2371() {
  return (
    <div className="relative shrink-0">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center pl-10 pr-0 py-0 relative">
          <div
            className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#000000] text-[10px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">FOUNDATIONS</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function MenuLabel() {
  return (
    <div className="h-[46px] relative shrink-0" data-name="menu label">
      <div className="box-border content-stretch flex flex-col gap-1 h-[46px] items-start justify-center p-0 relative">
        <Frame2149 />
        <Frame2371 />
      </div>
    </div>
  );
}

function Frame2422() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-1 items-center justify-start p-0 relative">
        <div
          className="h-[25.952px] relative shrink-0 w-[29px]"
          data-name="Vector"
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 29 26"
          >
            <path
              d={svgPaths.p158a0700}
              fill="var(--fill-0, #58A7AF)"
              id="Vector"
            />
          </svg>
        </div>
        <div
          className="flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-none relative shrink-0 text-[#58a7af] text-[16px] text-nowrap text-right whitespace-pre"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">IMPORTANT</p>
          <p className="block">NOTICE</p>
        </div>
      </div>
    </div>
  );
}

function Frame2394() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-4 items-start justify-center p-0 relative w-full">
        <Frame2422 />
        <div className="bg-[#58a7af] h-8 shrink-0 w-0.5" />
        <div
          className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[17px] relative shrink-0 text-[#1c1b1d] text-[14px] text-left text-nowrap whitespace-pre"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p
            className="block font-['Roboto:Bold',_sans-serif] font-bold mb-0"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            EnergyLink Services Currently Down
          </p>
          <p className="block">{`Anticipated Resolution in XX Hours `}</p>
        </div>
      </div>
    </div>
  );
}

function Surface2666() {
  return (
    <div
      className="absolute bottom-[1.211%] left-[0.962%] right-[0.608%] top-[0.854%]"
      data-name="surface2666"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 31 32"
      >
        <g id="surface2666">
          <path
            d={svgPaths.p246ca580}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Notifications() {
  return (
    <div
      className="h-8 mr-[-8px] overflow-clip relative shrink-0 w-[31.045px]"
      data-name="notifications"
    >
      <Surface2666 />
    </div>
  );
}

function Badge() {
  return (
    <div
      className="bg-[#58a7af] mr-[-8px] relative rounded-[60px] shrink-0 size-5"
      data-name="badge"
    >
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col items-center justify-center px-1 py-0 relative size-5">
          <div
            className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#ffffff] text-[14px] text-center w-1.5"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-[20px]">2</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2253() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row items-center justify-start pl-0 pr-2 py-0 relative">
        <Notifications />
        <Badge />
      </div>
    </div>
  );
}

function FileManager() {
  return (
    <div
      className="overflow-clip relative shrink-0 size-8"
      data-name="file manager"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 32"
      >
        <g id="surface30407">
          <path
            d={svgPaths.p11f3980}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Surface31589() {
  return (
    <div
      className="absolute aspect-[33.9364/31.1111] left-[0.621%] right-[2.418%] translate-y-[-50%]"
      data-name="surface31589"
      style={{ top: "calc(50% - 0.053168px)" }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 34 32"
      >
        <g id="surface31589">
          <path
            clipRule="evenodd"
            d={svgPaths.pb3f0100}
            fill="var(--fill-0, #989A9C)"
            fillRule="evenodd"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Help() {
  return (
    <div
      className="absolute h-[32.083px] left-[0.68px] overflow-clip top-[0.961px] w-[35px]"
      data-name="Help"
    >
      <Surface31589 />
    </div>
  );
}

function Help1() {
  return (
    <div
      className="absolute h-3.5 translate-x-[-50%] translate-y-[-50%] w-7"
      data-name="HELP"
      style={{ top: "calc(50% - 0.572727px)", left: "calc(50% + 13px)" }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 28 14"
      >
        <g id="HELP">
          <rect fill="var(--fill-0, #FF6515)" height="14" rx="2" width="28" />
          <path
            d={svgPaths.p1facf080}
            fill="var(--fill-0, white)"
            id="Vector"
          />
          <path
            d={svgPaths.p3bbee900}
            fill="var(--fill-0, white)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2355ee00}
            fill="var(--fill-0, white)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p29daf200}
            fill="var(--fill-0, white)"
            id="Vector_4"
          />
        </g>
      </svg>
    </div>
  );
}

function HelpButton() {
  return (
    <div
      className="h-[32.145px] relative shrink-0 w-[52px]"
      data-name="help button"
    >
      <Help />
      <Help1 />
    </div>
  );
}

function User() {
  return (
    <div className="overflow-clip relative shrink-0 size-3" data-name="user">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 12 12"
      >
        <g id="surface4191">
          <path
            d={svgPaths.p2664b100}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame2266() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-end p-0 relative size-full">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#56535b] text-[12px] text-right"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none">Phil Dunning</p>
        </div>
        <User />
      </div>
    </div>
  );
}

function Frame2267() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-end p-0 relative w-full">
        <div className="flex flex-row items-center self-stretch">
          <Frame2266 />
        </div>
      </div>
    </div>
  );
}

function Frame2268() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-end p-0 relative">
        <div
          className="font-['Roboto:Black',_sans-serif] font-black leading-[0] relative shrink-0 text-[#56535b] text-[14px] text-nowrap text-right"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">
            EXXON MOBIL PRODUCTION CO
          </p>
        </div>
        <div className="flex items-center justify-center relative shrink-0">
          <div className="flex-none scale-y-[-100%]">
            <div className="h-[6.316px] relative w-3" data-name="Triangle">
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 12 7"
              >
                <path
                  clipRule="evenodd"
                  d="M6 0L12 6.31579H0L6 0Z"
                  fill="var(--fill-0, #989A9C)"
                  fillRule="evenodd"
                  id="Triangle"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame144() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-[5px] items-end justify-center p-0 relative">
        <Frame2267 />
        <Frame2268 />
      </div>
    </div>
  );
}

function Frame2254() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-end p-0 relative">
        <Frame144 />
      </div>
    </div>
  );
}

function Frame2171() {
  return (
    <div className="h-[46px] relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2 h-[46px] items-start justify-end p-0 relative">
        <Frame2253 />
        <div className="bg-[#ddddde] h-8 shrink-0 w-0.5" />
        <FileManager />
        <div className="bg-[#ddddde] h-8 shrink-0 w-0.5" />
        <HelpButton />
        <div className="bg-[#ddddde] h-8 shrink-0 w-0.5" />
        <Frame2254 />
      </div>
    </div>
  );
}

function Frame2269() {
  return (
    <div className="bg-[#ffffff] h-[100px] relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row h-[100px] items-center justify-between pl-6 pr-4 py-0 relative w-full">
          <MenuLabel />
          <Frame2394 />
          <Frame2171 />
        </div>
      </div>
    </div>
  );
}

function Frame2255() {
  return (
    <div className="h-3.5 relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-1.5 h-3.5 items-center justify-center p-0 relative">
        <div
          className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#625f66] text-[14px] text-center text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">Dashboard</p>
        </div>
      </div>
    </div>
  );
}

function Frame2264() {
  return (
    <div className="relative self-stretch shrink-0 w-[11.144px]">
      <div className="flex flex-col items-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2.5 h-full items-center justify-start pb-0 pt-1 px-0 relative w-[11.144px]">
          <div className="flex items-center justify-center relative shrink-0">
            <div className="flex-none scale-y-[-100%]">
              <div className="h-[4.307px] relative w-2" data-name="Triangle">
                <svg
                  className="block size-full"
                  fill="none"
                  preserveAspectRatio="none"
                  viewBox="0 0 8 5"
                >
                  <path
                    clipRule="evenodd"
                    d="M4 0L8 4.30717H0L4 0Z"
                    fill="var(--fill-0, #625F66)"
                    fillRule="evenodd"
                    id="Triangle"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2263() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-1.5 items-start justify-center p-0 relative">
        <div
          className="font-['Roboto:Medium',_sans-serif] font-['Roboto:Regular',_sans-serif] font-medium font-normal leading-none relative shrink-0 text-[#625f66] text-[0px] text-left text-nowrap whitespace-pre"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p
            className="block mb-0 text-[14px]"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            Non-Operated
          </p>
          <p
            className="block text-[#b2b1b3] text-[10px]"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            Receiver
          </p>
        </div>
        <Frame2264 />
      </div>
    </div>
  );
}

function Frame2270() {
  return (
    <div className="relative self-stretch shrink-0 w-[11.144px]">
      <div className="flex flex-col items-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2.5 h-full items-center justify-start pb-0 pt-1 px-0 relative w-[11.144px]">
          <div className="flex items-center justify-center relative shrink-0">
            <div className="flex-none scale-y-[-100%]">
              <div className="h-[4.307px] relative w-2" data-name="Triangle">
                <svg
                  className="block size-full"
                  fill="none"
                  preserveAspectRatio="none"
                  viewBox="0 0 8 5"
                >
                  <path
                    clipRule="evenodd"
                    d="M4 0L8 4.30717H0L4 0Z"
                    fill="var(--fill-0, #625F66)"
                    fillRule="evenodd"
                    id="Triangle"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2271() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-1.5 items-start justify-center p-0 relative">
        <div
          className="font-['Roboto:Medium',_sans-serif] font-['Roboto:Regular',_sans-serif] font-medium font-normal leading-none relative shrink-0 text-[#625f66] text-[0px] text-left text-nowrap whitespace-pre"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p
            className="block mb-0 text-[14px]"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            Operated
          </p>
          <p
            className="block text-[#b2b1b3] text-[10px]"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            Sender
          </p>
        </div>
        <Frame2270 />
      </div>
    </div>
  );
}

function Frame2265() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center p-0 relative">
        <div
          className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#625f66] text-[14px] text-center text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">Reports</p>
        </div>
      </div>
    </div>
  );
}

function Dropdown() {
  return (
    <div className="h-1.5 relative shrink-0 w-3" data-name="dropdown">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 12 6"
      >
        <g id="dropdown">
          <path
            clipRule="evenodd"
            d={svgPaths.p13ba98f2}
            fill="var(--fill-0, #625F66)"
            fillRule="evenodd"
            id="Triangle"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame2272() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center p-0 relative">
        <div
          className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#625f66] text-[14px] text-center text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">{`Admin & Resources `}</p>
        </div>
        <Dropdown />
      </div>
    </div>
  );
}

function Frame2262() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center p-0 relative">
        <div
          className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#625f66] text-[14px] text-center text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">Enverus Apps</p>
        </div>
      </div>
    </div>
  );
}

function Frame2355() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-8 items-start justify-start p-0 relative w-full">
        <Frame2255 />
        <Frame2263 />
        <Frame2271 />
        <Frame2265 />
        <Frame2272 />
        <Frame2262 />
      </div>
    </div>
  );
}

function Frame2273() {
  return (
    <div className="bg-[#ffffff] relative shrink-0 w-full">
      <div className="absolute border-[#cbcdce] border-[0px_0px_1px] border-solid inset-0 pointer-events-none shadow-[0px_2px_2px_0px_rgba(0,0,0,0.15)]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-row items-start justify-between pb-3 pl-6 pr-4 pt-0 relative w-full">
          <Frame2355 />
        </div>
      </div>
    </div>
  );
}

function Frame2174() {
  return (
    <div className="h-12 relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-12 items-end justify-start p-0 relative">
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#625f66] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">Dashboard</p>
        </div>
      </div>
    </div>
  );
}

function Surface43575() {
  return (
    <div
      className="absolute bottom-[0.758%] left-0 right-0 top-[1.515%]"
      data-name="surface43575"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 18"
      >
        <g id="surface43575">
          <path
            d={svgPaths.p2806c600}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Building() {
  return (
    <div
      className="h-[18.333px] overflow-clip relative shrink-0 w-5"
      data-name="building"
    >
      <Surface43575 />
    </div>
  );
}

function User1() {
  return (
    <div
      className="absolute bottom-[6.467%] left-[5.556%] overflow-clip right-[5.556%] top-[4.644%]"
      data-name="user"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="surface4191">
          <path
            d={svgPaths.p39f74180}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function CompanyName() {
  return (
    <div
      className="overflow-clip relative shrink-0 size-[18px]"
      data-name="company name"
    >
      <User1 />
    </div>
  );
}

function Frame2215() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative">
        <CompanyName />
        <div
          className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#4d8f1e] text-[14px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">
            Hide My Assignments
          </p>
        </div>
      </div>
    </div>
  );
}

function Surface90656() {
  return (
    <div
      className="absolute bottom-[4.052%] left-0 right-0 top-[4%]"
      data-name="surface90656"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 18 17"
      >
        <g id="surface90656">
          <path
            d={svgPaths.p17b5b80}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function CompanyName1() {
  return (
    <div
      className="overflow-clip relative shrink-0 size-[18px]"
      data-name="company name"
    >
      <Surface90656 />
    </div>
  );
}

function Frame204() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative">
        <CompanyName1 />
        <div
          className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#4d8f1e] text-[14px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">Operator Lists</p>
        </div>
      </div>
    </div>
  );
}

function Frame2504() {
  return (
    <div className="relative shrink-0">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-6 items-center justify-start pl-4 pr-0 py-0 relative">
          <Frame2215 />
          <Frame204 />
        </div>
      </div>
    </div>
  );
}

function Frame2448() {
  return (
    <div className="absolute left-0 top-0">
      <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start p-0 relative">
        <Building />
        <div className="flex h-[18.628px] items-center justify-center relative shrink-0 w-[213.052px]">
          <div className="flex-none rotate-[359.831deg]">
            <div
              className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative text-[#989a9c] text-[18px] text-left text-nowrap"
              style={{ fontVariationSettings: "'wdth' 100" }}
            >
              <p className="block leading-none whitespace-pre">
                NON-OPERATING STATS
              </p>
            </div>
          </div>
        </div>
        <Frame2504 />
      </div>
    </div>
  );
}

function Frame2092() {
  return (
    <div className="h-8 relative shrink-0 w-[137px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-[137px]">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-none min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">Open</p>
          <p className="block">Disputes</p>
        </div>
      </div>
    </div>
  );
}

function Dispute() {
  return (
    <div className="relative shrink-0 size-6" data-name="dispute">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g clipPath="url(#clip0_1_520)" id="dispute">
          <path
            d={svgPaths.p31206500}
            fill="var(--fill-0, #CBCDCE)"
            id="Vector"
          />
        </g>
        <defs>
          <clipPath id="clip0_1_520">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame2099() {
  return (
    <div className="relative shrink-0 size-7">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative size-7">
        <Dispute />
      </div>
    </div>
  );
}

function Surface10888() {
  return (
    <div
      className="h-3 relative shrink-0 w-[12.718px]"
      data-name="surface10888"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 13 12"
      >
        <g id="surface10888">
          <path
            d={svgPaths.p1cfbc080}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Right2() {
  return (
    <div className="relative shrink-0 w-4" data-name="Right 2">
      <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center overflow-clip p-0 relative w-4">
        <Surface10888 />
      </div>
    </div>
  );
}

function Frame2091() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative w-full">
        <Frame2099 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#1c1b1d] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">XX</p>
        </div>
        <Right2 />
      </div>
    </div>
  );
}

function Frame2462() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative w-full">
        <Frame2091 />
      </div>
    </div>
  );
}

function Frame2506() {
  return (
    <div className="bg-[#ffffff] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0">
      <div className="absolute border-[#989a9c] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-0 pt-4 px-4 relative">
          <Frame2092 />
          <Frame2462 />
        </div>
      </div>
    </div>
  );
}

function Frame2505() {
  return (
    <div className="bg-[#ffffff] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-[169px]">
      <div className="absolute border-[#989a9c] border-[0px_1px_1px] border-solid inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start px-4 py-2 relative w-[169px]">
          <div
            className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#989a9c] text-[14px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Me</p>
          </div>
          <div
            className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#989a9c] text-[14px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">XX</p>
          </div>
          <div
            className="h-3 relative shrink-0 w-[12.718px]"
            data-name="Vector"
          >
            <svg
              className="block size-full"
              fill="none"
              preserveAspectRatio="none"
              viewBox="0 0 13 12"
            >
              <path
                d={svgPaths.p1cfbc080}
                fill="var(--fill-0, #4D8F1E)"
                id="Vector"
              />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2511() {
  return (
    <div className="h-[114px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col h-[114px] items-start justify-start p-0 relative">
        <Frame2506 />
        <Frame2505 />
      </div>
    </div>
  );
}

function Frame2094() {
  return (
    <div className="h-8 relative shrink-0 w-[137px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-[137px]">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-none min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">Invoices</p>
          <p className="block">to Process</p>
        </div>
      </div>
    </div>
  );
}

function InvoicesToProcess() {
  return (
    <div className="relative shrink-0 size-6" data-name="invoices to process">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="invoices to process">
          <path
            d={svgPaths.p17aa9580}
            fill="var(--fill-0, #CBCDCE)"
            id="Union"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame2100() {
  return (
    <div className="relative shrink-0 size-7">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative size-7">
        <InvoicesToProcess />
      </div>
    </div>
  );
}

function Surface10889() {
  return (
    <div
      className="h-3 relative shrink-0 w-[12.718px]"
      data-name="surface10888"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 13 12"
      >
        <g id="surface10888">
          <path
            d={svgPaths.p1cfbc080}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Right3() {
  return (
    <div className="relative shrink-0 w-4" data-name="Right 2">
      <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center overflow-clip p-0 relative w-4">
        <Surface10889 />
      </div>
    </div>
  );
}

function Frame2095() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative w-full">
        <Frame2100 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#1c1b1d] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">XXX</p>
        </div>
        <Right3 />
      </div>
    </div>
  );
}

function Frame2507() {
  return (
    <div className="bg-[#ffffff] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0">
      <div className="absolute border-[#989a9c] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-0 pt-4 px-4 relative">
          <Frame2094 />
          <Frame2095 />
        </div>
      </div>
    </div>
  );
}

function Frame2508() {
  return (
    <div className="bg-[#ffffff] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-[169px]">
      <div className="absolute border-[#989a9c] border-[0px_1px_1px] border-solid inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start px-4 py-2 relative w-[169px]">
          <div
            className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#989a9c] text-[14px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Me</p>
          </div>
          <div
            className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#989a9c] text-[14px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">XX</p>
          </div>
          <div
            className="h-3 relative shrink-0 w-[12.718px]"
            data-name="Vector"
          >
            <svg
              className="block size-full"
              fill="none"
              preserveAspectRatio="none"
              viewBox="0 0 13 12"
            >
              <path
                d={svgPaths.p1cfbc080}
                fill="var(--fill-0, #4D8F1E)"
                id="Vector"
              />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2512() {
  return (
    <div className="h-[114px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col h-[114px] items-start justify-start p-0 relative">
        <Frame2507 />
        <Frame2508 />
      </div>
    </div>
  );
}

function Frame2096() {
  return (
    <div className="h-8 relative shrink-0 w-[137px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-[137px]">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-none min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">Payments</p>
          <p className="block">to Process</p>
        </div>
      </div>
    </div>
  );
}

function PaymentsToProcess() {
  return (
    <div
      className="h-[19px] relative shrink-0 w-[26px]"
      data-name="payments to process"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 26 19"
      >
        <g clipPath="url(#clip0_1_566)" id="payments to process">
          <g id="surface13272">
            <path
              d={svgPaths.p2109180}
              fill="var(--fill-0, #CBCDCE)"
              id="Vector"
            />
            <path
              d={svgPaths.p1cf60900}
              fill="var(--fill-0, #CBCDCE)"
              id="Vector_2"
            />
          </g>
          <circle
            cx="11.5"
            cy="6.5"
            fill="var(--fill-0, #CBCDCE)"
            id="Ellipse 27"
            r="3.5"
          />
        </g>
        <defs>
          <clipPath id="clip0_1_566">
            <rect fill="white" height="19" width="26" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame2101() {
  return (
    <div className="relative shrink-0 size-7">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative size-7">
        <PaymentsToProcess />
      </div>
    </div>
  );
}

function Surface10890() {
  return (
    <div
      className="h-3 relative shrink-0 w-[12.718px]"
      data-name="surface10888"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 13 12"
      >
        <g id="surface10888">
          <path
            d={svgPaths.p1cfbc080}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Right4() {
  return (
    <div className="relative shrink-0 w-4" data-name="Right 2">
      <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center overflow-clip p-0 relative w-4">
        <Surface10890 />
      </div>
    </div>
  );
}

function Frame2093() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative w-full">
        <Frame2101 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#1c1b1d] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">XXX</p>
        </div>
        <Right4 />
      </div>
    </div>
  );
}

function Frame2509() {
  return (
    <div className="bg-[#ffffff] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0">
      <div className="absolute border-[#989a9c] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-0 pt-4 px-4 relative">
          <Frame2096 />
          <Frame2093 />
        </div>
      </div>
    </div>
  );
}

function Frame2510() {
  return (
    <div className="bg-[#ffffff] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-[169px]">
      <div className="absolute border-[#989a9c] border-[0px_1px_1px] border-solid inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start px-4 py-2 relative w-[169px]">
          <div
            className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#989a9c] text-[14px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Me</p>
          </div>
          <div
            className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#989a9c] text-[14px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">XX</p>
          </div>
          <div
            className="h-3 relative shrink-0 w-[12.718px]"
            data-name="Vector"
          >
            <svg
              className="block size-full"
              fill="none"
              preserveAspectRatio="none"
              viewBox="0 0 13 12"
            >
              <path
                d={svgPaths.p1cfbc080}
                fill="var(--fill-0, #4D8F1E)"
                id="Vector"
              />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2513() {
  return (
    <div className="h-[114px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col h-[114px] items-start justify-start p-0 relative">
        <Frame2509 />
        <Frame2510 />
      </div>
    </div>
  );
}

function Frame2097() {
  return (
    <div className="h-8 relative shrink-0 w-[137px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-[137px]">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-none min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">Open</p>
          <p className="block">Inquiries</p>
        </div>
      </div>
    </div>
  );
}

function Surface12676() {
  return (
    <div
      className="absolute bottom-0 left-0 right-[0.083%] top-0"
      data-name="surface12676"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 22 24"
      >
        <g id="surface12676">
          <path
            d={svgPaths.p2c50f200}
            fill="var(--fill-0, #CBCDCE)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Decision1() {
  return (
    <div
      className="h-6 overflow-clip relative shrink-0 w-[21.6px]"
      data-name="Decision 1"
    >
      <Surface12676 />
    </div>
  );
}

function Frame2102() {
  return (
    <div className="relative shrink-0 size-7">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative size-7">
        <Decision1 />
      </div>
    </div>
  );
}

function Surface10891() {
  return (
    <div
      className="h-3 relative shrink-0 w-[12.718px]"
      data-name="surface10888"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 13 12"
      >
        <g id="surface10888">
          <path
            d={svgPaths.p1cfbc080}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Right5() {
  return (
    <div className="relative shrink-0 w-4" data-name="Right 2">
      <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center overflow-clip p-0 relative w-4">
        <Surface10891 />
      </div>
    </div>
  );
}

function Frame2098() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative w-full">
        <Frame2102 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#1c1b1d] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">XX</p>
        </div>
        <Right5 />
      </div>
    </div>
  );
}

function Frame2517() {
  return (
    <div className="bg-[#ffffff] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0">
      <div className="absolute border-[#989a9c] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-0 pt-4 px-4 relative">
          <Frame2097 />
          <Frame2098 />
        </div>
      </div>
    </div>
  );
}

function Frame2518() {
  return (
    <div className="bg-[#ffffff] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-[169px]">
      <div className="absolute border-[#989a9c] border-[0px_1px_1px] border-solid inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start px-4 py-2 relative w-[169px]">
          <div
            className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#989a9c] text-[14px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Me</p>
          </div>
          <div
            className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#989a9c] text-[14px] text-left text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">XX</p>
          </div>
          <div
            className="h-3 relative shrink-0 w-[12.718px]"
            data-name="Vector"
          >
            <svg
              className="block size-full"
              fill="none"
              preserveAspectRatio="none"
              viewBox="0 0 13 12"
            >
              <path
                d={svgPaths.p1cfbc080}
                fill="var(--fill-0, #4D8F1E)"
                id="Vector"
              />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2514() {
  return (
    <div className="h-[114px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col h-[114px] items-start justify-start p-0 relative">
        <Frame2517 />
        <Frame2518 />
      </div>
    </div>
  );
}

function Frame2103() {
  return (
    <div className="h-8 relative shrink-0 w-[137px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-[137px]">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-none min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">Statements</p>
          <p className="block">to Process</p>
        </div>
      </div>
    </div>
  );
}

function Surface13542() {
  return (
    <div
      className="absolute bottom-0 left-0 right-[1.775%] top-0"
      data-name="surface13542"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 22 24"
      >
        <g id="surface13542">
          <path
            d={svgPaths.p255ada00}
            fill="var(--fill-0, #CBCDCE)"
            id="Vector"
          />
          <path
            d={svgPaths.p1963b000}
            fill="var(--fill-0, #CBCDCE)"
            id="Vector_2"
          />
        </g>
      </svg>
    </div>
  );
}

function PaymentsToProcess1() {
  return (
    <div
      className="h-6 overflow-clip relative shrink-0 w-[22.286px]"
      data-name="payments to process"
    >
      <Surface13542 />
    </div>
  );
}

function Frame2104() {
  return (
    <div className="relative shrink-0 size-7">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative size-7">
        <PaymentsToProcess1 />
      </div>
    </div>
  );
}

function Surface10892() {
  return (
    <div
      className="h-3 relative shrink-0 w-[12.718px]"
      data-name="surface10888"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 13 12"
      >
        <g id="surface10888">
          <path
            d={svgPaths.p1cfbc080}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Right6() {
  return (
    <div className="relative shrink-0 w-4" data-name="Right 2">
      <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center overflow-clip p-0 relative w-4">
        <Surface10892 />
      </div>
    </div>
  );
}

function Frame2105() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative w-full">
        <Frame2104 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#1c1b1d] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">XX</p>
        </div>
        <Right6 />
      </div>
    </div>
  );
}

function Frame2519() {
  return (
    <div className="bg-[#ffffff] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0">
      <div className="absolute border-[#989a9c] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-0 pt-4 px-4 relative">
          <Frame2103 />
          <Frame2105 />
        </div>
      </div>
    </div>
  );
}

function Frame2520() {
  return (
    <div className="bg-[#ffffff] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-[169px]">
      <div className="absolute border-[#989a9c] border-[0px_1px_1px] border-solid inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start px-4 py-2 w-[169px]" />
      </div>
    </div>
  );
}

function Frame2515() {
  return (
    <div className="h-[114px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col h-[114px] items-start justify-start p-0 relative">
        <Frame2519 />
        <Frame2520 />
      </div>
    </div>
  );
}

function Frame2106() {
  return (
    <div className="h-8 relative shrink-0 w-[137px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-[137px]">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-none min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">1099s</p>
          <p className="block">to View</p>
        </div>
      </div>
    </div>
  );
}

function Component1099SToView() {
  return (
    <div
      className="h-6 overflow-clip relative shrink-0 w-[21.818px]"
      data-name="1099s to view"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 22 24"
      >
        <g id="surface15114">
          <path
            d={svgPaths.p10e94a80}
            fill="var(--fill-0, #CBCDCE)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame2107() {
  return (
    <div className="relative shrink-0 size-7">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative size-7">
        <Component1099SToView />
      </div>
    </div>
  );
}

function Surface10893() {
  return (
    <div
      className="h-3 relative shrink-0 w-[12.718px]"
      data-name="surface10888"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 13 12"
      >
        <g id="surface10888">
          <path
            d={svgPaths.p1cfbc080}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Right7() {
  return (
    <div className="relative shrink-0 w-4" data-name="Right 2">
      <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center overflow-clip p-0 relative w-4">
        <Surface10893 />
      </div>
    </div>
  );
}

function Frame2108() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative w-full">
        <Frame2107 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#1c1b1d] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">XX</p>
        </div>
        <Right7 />
      </div>
    </div>
  );
}

function Frame2521() {
  return (
    <div className="bg-[#ffffff] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0">
      <div className="absolute border-[#989a9c] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-0 pt-4 px-4 relative">
          <Frame2106 />
          <Frame2108 />
        </div>
      </div>
    </div>
  );
}

function Frame2522() {
  return (
    <div className="bg-[#ffffff] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-[169px]">
      <div className="absolute border-[#989a9c] border-[0px_1px_1px] border-solid inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start px-4 py-2 w-[169px]" />
      </div>
    </div>
  );
}

function Frame2516() {
  return (
    <div className="h-[114px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col h-[114px] items-start justify-start p-0 relative">
        <Frame2521 />
        <Frame2522 />
      </div>
    </div>
  );
}

function Frame2177() {
  return (
    <div className="absolute left-0 top-[30.336px]">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-row gap-4 items-start justify-start pl-9 pr-6 py-0 relative">
          <Frame2511 />
          <Frame2512 />
          <Frame2513 />
          <Frame2514 />
          <Frame2515 />
          <Frame2516 />
        </div>
      </div>
    </div>
  );
}

function Frame2419() {
  return (
    <div className="h-[146.336px] relative shrink-0 w-[1154px]">
      <Frame2448 />
      <Frame2177 />
    </div>
  );
}

function Surface43576() {
  return (
    <div
      className="absolute bottom-[0.758%] left-0 right-0 top-[1.515%]"
      data-name="surface43575"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 18"
      >
        <g id="surface43575">
          <path
            d={svgPaths.p2806c600}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Building1() {
  return (
    <div
      className="h-[18.333px] overflow-clip relative shrink-0 w-5"
      data-name="building"
    >
      <Surface43576 />
    </div>
  );
}

function Frame2176() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start p-0 relative">
        <Building1 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#989a9c] text-[18px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">{` OPERATING STATS `}</p>
        </div>
      </div>
    </div>
  );
}

function Frame2109() {
  return (
    <div className="basis-0 grow h-8 min-h-px min-w-px relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-full">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-none min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">Open</p>
          <p className="block">Disputes</p>
        </div>
      </div>
    </div>
  );
}

function Frame2112() {
  return (
    <div className="h-8 relative shrink-0 w-[137px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-[137px]">
        <Frame2109 />
      </div>
    </div>
  );
}

function Dispute1() {
  return (
    <div className="relative shrink-0 size-6" data-name="dispute">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g clipPath="url(#clip0_1_520)" id="dispute">
          <path
            d={svgPaths.p31206500}
            fill="var(--fill-0, #CBCDCE)"
            id="Vector"
          />
        </g>
        <defs>
          <clipPath id="clip0_1_520">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame2113() {
  return (
    <div className="relative shrink-0 size-7">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative size-7">
        <Dispute1 />
      </div>
    </div>
  );
}

function Surface10894() {
  return (
    <div
      className="h-3 relative shrink-0 w-[12.718px]"
      data-name="surface10888"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 13 12"
      >
        <g id="surface10888">
          <path
            d={svgPaths.p1cfbc080}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Right8() {
  return (
    <div className="relative shrink-0 w-4" data-name="Right 2">
      <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center overflow-clip p-0 relative w-4">
        <Surface10894 />
      </div>
    </div>
  );
}

function Frame2114() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative w-full">
        <Frame2113 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#1c1b1d] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">XX</p>
        </div>
        <Right8 />
      </div>
    </div>
  );
}

function Frame2523() {
  return (
    <div className="bg-[#ffffff] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0">
      <div className="absolute border-[#989a9c] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-0 pt-4 px-4 relative">
          <Frame2112 />
          <Frame2114 />
        </div>
      </div>
    </div>
  );
}

function Frame2524() {
  return (
    <div className="bg-[#ffffff] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-[169px]">
      <div className="absolute border-[#989a9c] border-[0px_1px_1px] border-solid inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start px-4 py-2 w-[169px]" />
      </div>
    </div>
  );
}

function Frame2525() {
  return (
    <div className="h-[114px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col h-[114px] items-start justify-start p-0 relative">
        <Frame2523 />
        <Frame2524 />
      </div>
    </div>
  );
}

function Frame2115() {
  return (
    <div className="basis-0 grow h-8 min-h-px min-w-px relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-full">
        <div
          className="basis-0 font-['Roboto:Regular',_sans-serif] font-normal grow leading-none min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-0">Open</p>
          <p className="block">Inquiries</p>
        </div>
      </div>
    </div>
  );
}

function Frame2118() {
  return (
    <div className="h-8 relative shrink-0 w-[137px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center p-0 relative w-[137px]">
        <Frame2115 />
      </div>
    </div>
  );
}

function Surface12677() {
  return (
    <div
      className="absolute bottom-0 left-0 right-[0.083%] top-0"
      data-name="surface12676"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 22 24"
      >
        <g id="surface12676">
          <path
            d={svgPaths.p2c50f200}
            fill="var(--fill-0, #CBCDCE)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Decision2() {
  return (
    <div
      className="h-6 overflow-clip relative shrink-0 w-[21.6px]"
      data-name="Decision 1"
    >
      <Surface12677 />
    </div>
  );
}

function Frame2119() {
  return (
    <div className="relative shrink-0 size-7">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative size-7">
        <Decision2 />
      </div>
    </div>
  );
}

function Surface10895() {
  return (
    <div
      className="h-3 relative shrink-0 w-[12.718px]"
      data-name="surface10888"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 13 12"
      >
        <g id="surface10888">
          <path
            d={svgPaths.p1cfbc080}
            fill="var(--fill-0, #4D8F1E)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Right9() {
  return (
    <div className="relative shrink-0 w-4" data-name="Right 2">
      <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center overflow-clip p-0 relative w-4">
        <Surface10895 />
      </div>
    </div>
  );
}

function Frame2121() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative w-full">
        <Frame2119 />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#1c1b1d] text-[24px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">XX</p>
        </div>
        <Right9 />
      </div>
    </div>
  );
}

function Frame2526() {
  return (
    <div className="bg-[#ffffff] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0">
      <div className="absolute border-[#989a9c] border-[1px_1px_0px] border-solid inset-0 pointer-events-none rounded-tl-[8px] rounded-tr-[8px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-0 pt-4 px-4 relative">
          <Frame2118 />
          <Frame2121 />
        </div>
      </div>
    </div>
  );
}

function Frame2527() {
  return (
    <div className="bg-[#ffffff] relative rounded-bl-[8px] rounded-br-[8px] shrink-0 w-[169px]">
      <div className="absolute border-[#989a9c] border-[0px_1px_1px] border-solid inset-0 pointer-events-none rounded-bl-[8px] rounded-br-[8px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[9px] items-center justify-start px-4 py-2 w-[169px]" />
      </div>
    </div>
  );
}

function Frame2528() {
  return (
    <div className="h-[114px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col h-[114px] items-start justify-start p-0 relative">
        <Frame2526 />
        <Frame2527 />
      </div>
    </div>
  );
}

function Frame2110() {
  return (
    <div className="relative shrink-0">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start pl-9 pr-0 py-0 relative">
          <Frame2525 />
          <Frame2528 />
        </div>
      </div>
    </div>
  );
}

function Frame2420() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-3 items-start justify-start p-0 relative">
        <Frame2176 />
        <Frame2110 />
      </div>
    </div>
  );
}

function Surface40396() {
  return (
    <div
      className="absolute bottom-[8.899%] left-[0.001%] right-[9.09%] top-[1.284%]"
      data-name="surface40396"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 19"
      >
        <g id="surface40396">
          <path
            d={svgPaths.p3a5cd400}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function News() {
  return (
    <div
      className="h-[20.216px] overflow-clip relative shrink-0 w-[22px]"
      data-name="news"
    >
      <Surface40396 />
    </div>
  );
}

function Frame2111() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start p-0 relative">
        <News />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#989a9c] text-[18px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">{`ENVERUS NEWS & EVENTS`}</p>
        </div>
      </div>
    </div>
  );
}

function Frame2116() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative w-full">
        <Frame2111 />
      </div>
    </div>
  );
}

function Frame2117() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-9 items-start justify-start p-0 relative w-full">
        <Frame2116 />
      </div>
    </div>
  );
}

function Frame233() {
  return (
    <div className="bg-[#ffffff] h-7 relative rounded shrink-0 w-20">
      <div className="absolute border border-[#4d8f1e] border-solid inset-0 pointer-events-none rounded" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-7 items-center justify-center px-4 py-2.5 relative w-20">
          <div
            className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#4d8f1e] text-[12px] text-center text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Read</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2155() {
  return (
    <div className="absolute left-0 top-0 w-[511px]">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[45px] items-start justify-start pl-9 pr-0 py-0 relative w-[511px]">
          <div
            className="basis-0 font-['Roboto:SemiBold',_sans-serif] font-semibold grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-[20px]">{`Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt `}</p>
          </div>
          <Frame233 />
        </div>
      </div>
    </div>
  );
}

function Frame2152() {
  return (
    <div className="bg-[#ffffff] h-7 relative rounded shrink-0 w-20">
      <div className="absolute border border-[#4d8f1e] border-solid inset-0 pointer-events-none rounded" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-7 items-center justify-center px-4 py-2.5 relative w-20">
          <div
            className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#4d8f1e] text-[12px] text-center text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Watch</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2156() {
  return (
    <div className="absolute left-0 top-16 w-[511px]">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[45px] items-start justify-start pl-9 pr-0 py-0 relative w-[511px]">
          <div
            className="basis-0 font-['Roboto:SemiBold',_sans-serif] font-semibold grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-[20px]">{`Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt `}</p>
          </div>
          <Frame2152 />
        </div>
      </div>
    </div>
  );
}

function Frame2153() {
  return (
    <div className="bg-[#ffffff] h-7 relative rounded shrink-0 w-20">
      <div className="absolute border border-[#4d8f1e] border-solid inset-0 pointer-events-none rounded" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-7 items-center justify-center px-4 py-2.5 relative w-20">
          <div
            className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#4d8f1e] text-[12px] text-center text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Register</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2157() {
  return (
    <div className="absolute left-0 top-32 w-[511px]">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[45px] items-start justify-start pl-9 pr-0 py-0 relative w-[511px]">
          <div
            className="basis-0 font-['Roboto:SemiBold',_sans-serif] font-semibold grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-[20px]">{`Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt `}</p>
          </div>
          <Frame2153 />
        </div>
      </div>
    </div>
  );
}

function Frame2154() {
  return (
    <div className="bg-[#ffffff] h-7 relative rounded shrink-0 w-20">
      <div className="absolute border border-[#4d8f1e] border-solid inset-0 pointer-events-none rounded" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-7 items-center justify-center px-4 py-2.5 relative w-20">
          <div
            className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#4d8f1e] text-[12px] text-center text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Explore</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame2158() {
  return (
    <div className="absolute left-0 top-48 w-[511px]">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[45px] items-start justify-start pl-9 pr-0 py-0 relative w-[511px]">
          <div
            className="basis-0 font-['Roboto:SemiBold',_sans-serif] font-semibold grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#625f66] text-[16px] text-left"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-[20px]">{`Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt `}</p>
          </div>
          <Frame2154 />
        </div>
      </div>
    </div>
  );
}

function Frame2423() {
  return (
    <div className="h-60 relative shrink-0 w-[511px]">
      <Frame2155 />
      <Frame2156 />
      <Frame2157 />
      <Frame2158 />
    </div>
  );
}

function Frame2175() {
  return (
    <div className="relative shrink-0 w-[511px]">
      <div className="box-border content-stretch flex flex-col gap-3 items-end justify-start p-0 relative w-[511px]">
        <Frame2117 />
        <Frame2423 />
      </div>
    </div>
  );
}

function Frame2163() {
  return (
    <div className="absolute left-[-101px] top-[-15px]">
      <div className="box-border content-stretch flex flex-row gap-2.5 items-center justify-center p-0 relative">
        <div
          className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#625f66] text-[20px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">
            Lorem Ipsum Dolor Sit Amet
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame2132() {
  return (
    <div className="[grid-area:1_/_1] h-[39px] ml-[129px] mt-[42px] relative w-[289px]">
      <Frame2163 />
    </div>
  );
}

function Frame234() {
  return (
    <div className="[grid-area:1_/_1] bg-[#ff5f29] h-8 ml-[449px] mt-[21px] relative rounded">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-8 items-center justify-center px-4 py-2.5 relative">
          <div
            className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#ffffff] text-[14px] text-center text-nowrap"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-none whitespace-pre">Visit</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Surface41399() {
  return (
    <div
      className="absolute bottom-[2.396%] left-[3.729%] right-[2.396%] top-[3.729%]"
      data-name="surface41399"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 19 19"
      >
        <g id="surface41399">
          <path
            d={svgPaths.p226f4800}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function CheckMark1() {
  return (
    <div
      className="[grid-area:1_/_1] ml-7 mt-24 overflow-clip relative size-5"
      data-name="Check Mark 1"
    >
      <Surface41399 />
    </div>
  );
}

function Surface41400() {
  return (
    <div
      className="absolute bottom-[2.396%] left-[3.729%] right-[2.396%] top-[3.729%]"
      data-name="surface41399"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 19 19"
      >
        <g id="surface41399">
          <path
            d={svgPaths.p226f4800}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function CheckMark2() {
  return (
    <div
      className="[grid-area:1_/_1] ml-7 mt-[158px] overflow-clip relative size-5"
      data-name="Check Mark 2"
    >
      <Surface41400 />
    </div>
  );
}

function Surface41401() {
  return (
    <div
      className="absolute bottom-[2.396%] left-[3.729%] right-[2.396%] top-[3.729%]"
      data-name="surface41399"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 19 19"
      >
        <g id="surface41399">
          <path
            d={svgPaths.p226f4800}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function CheckMark3() {
  return (
    <div
      className="[grid-area:1_/_1] ml-[27px] mt-[215px] overflow-clip relative size-5"
      data-name="Check Mark 3"
    >
      <Surface41401 />
    </div>
  );
}

function Group553() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <div className="[grid-area:1_/_1] bg-[#ffffff] h-[287px] ml-0 mt-0 rounded-lg w-[539px]" />
      <div
        className="[grid-area:1_/_1] bg-center bg-cover bg-no-repeat h-[171px] ml-[390px] mt-[108px] w-36"
        data-name="image 38"
        style={{ backgroundImage: `url('${imgImage38}')` }}
      />
      <div
        className="[grid-area:1_/_1] bg-center bg-cover bg-no-repeat h-[230px] ml-0 mt-0 opacity-70 w-[142px]"
        data-name="image 39"
        style={{ backgroundImage: `url('${imgImage39}')` }}
      />
      <Frame2132 />
      <Frame234 />
      <div
        className="[grid-area:1_/_1] font-['Roboto:Black',_sans-serif] font-black ml-7 mt-[62px] relative text-[#55bc2f] text-[18px] text-left w-[491px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[22px]">
          LOREM IPSUM DOLOR SIT AMET CONSECTETUR
        </p>
      </div>
      <div
        className="[grid-area:1_/_1] font-['Roboto:Regular',_sans-serif] font-normal leading-none ml-[62px] mt-24 relative text-[#625f66] text-[0px] text-left w-[322px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="block font-['Roboto:Bold',_sans-serif] font-bold mb-0 text-[16px]"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Lorem Ipsum Dolor
        </p>
        <p className="block mb-0 text-[#989a9c] text-[14px]">{`Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore `}</p>
        <p className="block mb-0 text-[16px]">&nbsp;</p>
        <p
          className="block font-['Roboto:Bold',_sans-serif] font-bold mb-0 text-[16px]"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Lorem Ipsum Dolor
        </p>
        <p className="block mb-0 text-[#989a9c] text-[14px]">{`Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore `}</p>
        <p className="block mb-0 text-[16px]">&nbsp;</p>
        <p
          className="block font-['Roboto:Bold',_sans-serif] font-bold mb-0 text-[16px]"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Lorem Ipsum Dolor
        </p>
        <p className="block mb-0 text-[#989a9c] text-[14px]">
          Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua
          ipsum dolor sit amet
        </p>
        <p className="block text-[16px]">&nbsp;</p>
      </div>
      <CheckMark1 />
      <CheckMark2 />
      <CheckMark3 />
    </div>
  );
}

function Frame2172() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-[42px] items-start justify-start p-0 relative">
        <Frame2175 />
        <Group553 />
      </div>
    </div>
  );
}

function Surface40694() {
  return (
    <div
      className="absolute bottom-[2.488%] left-[0.658%] right-[0.658%] top-[1.389%]"
      data-name="surface40694"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 19"
      >
        <g id="surface40694">
          <path
            d={svgPaths.p373ad080}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Support() {
  return (
    <div
      className="h-[18.947px] overflow-clip relative shrink-0 w-5"
      data-name="support"
    >
      <Surface40694 />
    </div>
  );
}

function Frame2178() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-4 items-center justify-start p-0 relative">
        <Support />
        <div
          className="font-['Roboto:Bold',_sans-serif] font-bold leading-[0] relative shrink-0 text-[#989a9c] text-[18px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">
            ENERGYLINK CLIENT SUPPORT
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame2414() {
  return (
    <div className="h-4 relative shrink-0 w-[225px]">
      <div
        className="absolute font-['Roboto:Regular',_sans-serif] font-normal leading-[0] left-0 text-[#58a7af] text-[16px] text-left text-nowrap top-0"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-none whitespace-pre">
          For immediate assistance...
        </p>
      </div>
    </div>
  );
}

function Frame2413() {
  return (
    <div className="h-[76px] relative shrink-0 w-[202px]">
      <div className="box-border content-stretch flex flex-col gap-4 h-[76px] items-start justify-start leading-[0] p-0 relative text-[16px] text-left w-[202px]">
        <div
          className="font-['Roboto:Black',_sans-serif] font-black relative shrink-0 text-[#58a7af] w-full"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none">SUPPORT DESK HOURS</p>
        </div>
        <div
          className="font-['Roboto:Regular',_sans-serif] font-normal leading-none relative shrink-0 text-[#1c1b1d] w-full"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-3">Monday - Friday, 8 AM -5 PM</p>
          <p className="block">Central Standard Time</p>
        </div>
      </div>
    </div>
  );
}

function Surface40992() {
  return (
    <div
      className="h-[18.741px] relative shrink-0 w-[18.742px]"
      data-name="surface40992"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 19 19"
      >
        <g id="surface40992">
          <path
            d={svgPaths.p3f9dbc00}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Surface41092() {
  return (
    <div
      className="h-[12.639px] relative shrink-0 w-[19.21px]"
      data-name="surface41092"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 13"
      >
        <g id="surface41092">
          <path
            d={svgPaths.p206e3500}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame2408() {
  return (
    <div className="relative self-stretch shrink-0 w-[19.451px]">
      <div className="box-border content-stretch flex flex-col h-full items-start justify-between p-0 relative w-[19.451px]">
        <Surface40992 />
        <Surface41092 />
      </div>
    </div>
  );
}

function Frame2410() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-[9px] items-start justify-start p-0 relative">
        <Frame2408 />
        <div
          className="font-['Roboto:Regular',_sans-serif] font-normal leading-none relative shrink-0 text-[#1c1b1d] text-[16px] text-left text-nowrap whitespace-pre"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-3">1-888-573-3364</p>
          <p className="block">support@energylink.com</p>
        </div>
      </div>
    </div>
  );
}

function Frame2412() {
  return (
    <div className="h-[76px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-4 h-[76px] items-start justify-start p-0 relative">
        <div
          className="font-['Roboto:Black',_sans-serif] font-black leading-[0] relative shrink-0 text-[#58a7af] text-[16px] text-left text-nowrap"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none whitespace-pre">
            APPLICATION SUPPORT
          </p>
        </div>
        <Frame2410 />
      </div>
    </div>
  );
}

function Surface40993() {
  return (
    <div
      className="h-[18.741px] relative shrink-0 w-[18.742px]"
      data-name="surface40992"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 19 19"
      >
        <g id="surface40992">
          <path
            d={svgPaths.p3f9dbc00}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Surface41093() {
  return (
    <div
      className="h-[12.639px] relative shrink-0 w-[19.21px]"
      data-name="surface41092"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 13"
      >
        <g id="surface41092">
          <path
            d={svgPaths.p206e3500}
            fill="var(--fill-0, #989A9C)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame2417() {
  return (
    <div className="relative self-stretch shrink-0 w-[19.451px]">
      <div className="box-border content-stretch flex flex-col h-full items-start justify-between p-0 relative w-[19.451px]">
        <Surface40993 />
        <Surface41093 />
      </div>
    </div>
  );
}

function Frame2409() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-[9px] items-start justify-start p-0 relative w-full">
        <Frame2417 />
        <div
          className="font-['Roboto:Regular',_sans-serif] font-normal leading-none relative shrink-0 text-[#1c1b1d] text-[16px] text-left text-nowrap whitespace-pre"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block mb-3">1-512-566-4680</p>
          <p className="block">accountsreceivable@energylink.com</p>
        </div>
      </div>
    </div>
  );
}

function Frame2411() {
  return (
    <div className="relative shrink-0 w-[289.451px]">
      <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative w-[289.451px]">
        <div
          className="font-['Roboto:Black',_sans-serif] font-black leading-[0] relative shrink-0 text-[#58a7af] text-[16px] text-left w-full"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          <p className="block leading-none">BILLING SUPPORT</p>
        </div>
        <Frame2409 />
      </div>
    </div>
  );
}

function Frame2415() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-20 items-center justify-start p-0 relative w-full">
        <Frame2413 />
        <Frame2412 />
        <Frame2411 />
      </div>
    </div>
  );
}

function Frame2416() {
  return (
    <div className="relative shrink-0 w-[1154px]">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-3 items-start justify-start pl-9 pr-0 py-0 relative w-[1154px]">
          <Frame2414 />
          <Frame2415 />
        </div>
      </div>
    </div>
  );
}

function Frame2421() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-3 items-start justify-start p-0 relative">
        <Frame2178 />
        <Frame2416 />
      </div>
    </div>
  );
}

function Frame2372() {
  return (
    <div className="h-[1136px] relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-6 h-[1136px] items-start justify-start p-0 relative">
        <Frame2174 />
        <Frame2419 />
        <Frame2420 />
        <Frame2172 />
        <Frame2421 />
      </div>
    </div>
  );
}

function Surface52752() {
  return (
    <div className="absolute inset-[8.333%]" data-name="surface52752">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 80 80"
      >
        <g id="surface52752">
          <path
            d={svgPaths.p3327f200}
            fill="var(--fill-0, black)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function MaleUser2() {
  return (
    <div
      className="overflow-clip relative shrink-0 size-24"
      data-name="Male User 2"
    >
      <Surface52752 />
    </div>
  );
}

function Frame2169() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full">
      <div className="flex flex-col items-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-start pl-6 pr-0 py-0 relative size-full">
          <Frame2372 />
          <MaleUser2 />
        </div>
      </div>
    </div>
  );
}

function Frame2173() {
  return (
    <div className="h-[1060px] relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-col h-[1060px] items-start justify-start p-0 relative w-full">
        <Frame2269 />
        <Frame2273 />
        <Frame2169 />
      </div>
    </div>
  );
}

function Frame2120() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-col items-start justify-start p-0 relative size-full">
        <Frame2173 />
      </div>
    </div>
  );
}

function Frame2164() {
  return (
    <div className="absolute bg-[#f8f8f8] h-[1024px] left-0 rounded-2xl top-0 w-[1440px]">
      <div className="box-border content-stretch flex flex-col h-[1024px] items-start justify-start overflow-clip p-0 relative w-[1440px]">
        <Frame2120 />
      </div>
    </div>
  );
}

export default function Group589() {
  return (
    <div className="relative size-full">
      <Frame2164 />
    </div>
  );
}