import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { FileText, Clock, CheckCircle, AlertTriangle, Users, TrendingUp } from 'lucide-react';

const caseStatusData = [
  { name: 'New', value: 12, color: '#58a7af' },
  { name: 'In Progress', value: 28, color: '#4d8f1e' },
  { name: 'Resolved', value: 45, color: '#8b5cf6' },
  { name: 'Closed', value: 15, color: '#989a9c' }
];

const weeklyData = [
  { name: 'Mon', new: 4, resolved: 8 },
  { name: 'Tue', new: 6, resolved: 5 },
  { name: 'Wed', new: 8, resolved: 12 },
  { name: 'Thu', new: 5, resolved: 9 },
  { name: 'Fri', new: 7, resolved: 6 },
  { name: 'Sat', new: 3, resolved: 4 },
  { name: 'Sun', new: 2, resolved: 3 }
];

export function Dashboard() {
  return (
    <div className="p-6 space-y-6 bg-[#f8f8f8]">
      {/* Page Title */}
      <div className="flex items-end h-12">
        <h1 className="text-[#625f66] font-bold text-2xl leading-none">Dashboard</h1>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-white border border-[#cbcdce]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#625f66]">Open Cases</CardTitle>
            <FileText className="h-4 w-4 text-[#989a9c]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1c1b1d]">40</div>
            <p className="text-xs text-[#989a9c]">
              <span className="text-[#4d8f1e]">↓ 12%</span> from last week
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white border border-[#cbcdce]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#625f66]">Avg Resolution Time</CardTitle>
            <Clock className="h-4 w-4 text-[#989a9c]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1c1b1d]">2.4 days</div>
            <p className="text-xs text-[#989a9c]">
              <span className="text-[#4d8f1e]">↓ 8%</span> from last week
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white border border-[#cbcdce]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#625f66]">Cases Resolved</CardTitle>
            <CheckCircle className="h-4 w-4 text-[#989a9c]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1c1b1d]">45</div>
            <p className="text-xs text-[#989a9c]">
              <span className="text-[#4d8f1e]">↑ 22%</span> from last week
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white border border-[#cbcdce]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-[#625f66]">Active Operators</CardTitle>
            <Users className="h-4 w-4 text-[#989a9c]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#1c1b1d]">8</div>
            <p className="text-xs text-[#989a9c]">
              2 operators at capacity
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-white border border-[#cbcdce]">
          <CardHeader>
            <CardTitle className="text-[#625f66] font-bold">Case Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={caseStatusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {caseStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border border-[#cbcdce]">
          <CardHeader>
            <CardTitle className="text-[#625f66] font-bold">Weekly Case Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="new" fill="#58a7af" name="New Cases" />
                  <Bar dataKey="resolved" fill="#4d8f1e" name="Resolved Cases" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Operator Workload */}
      <Card className="bg-white border border-[#cbcdce]">
        <CardHeader>
          <CardTitle className="text-[#625f66] font-bold">Operator Workload</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: 'Sarah Johnson', cases: 8, capacity: 10, status: 'Available' },
              { name: 'Mike Chen', cases: 10, capacity: 10, status: 'At Capacity' },
              { name: 'Emma Davis', cases: 6, capacity: 10, status: 'Available' },
              { name: 'Alex Rodriguez', cases: 9, capacity: 10, status: 'Available' },
              { name: 'Lisa Wang', cases: 10, capacity: 10, status: 'At Capacity' }
            ].map((operator, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 rounded-full bg-[#f3f3f5] border border-[#cbcdce] flex items-center justify-center">
                    <span className="text-[#625f66] font-medium text-sm">
                      {operator.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-[#1c1b1d]">{operator.name}</p>
                    <p className="text-sm text-[#989a9c]">{operator.cases}/{operator.capacity} cases</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <Progress 
                    value={(operator.cases / operator.capacity) * 100} 
                    className="w-24 bg-[#f3f3f5]" 
                  />
                  <Badge 
                    className={operator.status === 'At Capacity' 
                      ? 'bg-[#ff6515] text-white border-[#ff6515]' 
                      : 'bg-[#4d8f1e] text-white border-[#4d8f1e]'
                    }
                  >
                    {operator.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="bg-white border border-[#cbcdce]">
        <CardHeader>
          <CardTitle className="text-[#625f66] font-bold">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { type: 'case_created', text: 'New case #CRM-445 created by John Doe', time: '2 minutes ago', icon: FileText },
              { type: 'case_resolved', text: 'Case #CRM-442 resolved by Sarah Johnson', time: '15 minutes ago', icon: CheckCircle },
              { type: 'priority_change', text: 'Case #CRM-443 priority changed to High', time: '1 hour ago', icon: AlertTriangle },
              { type: 'assignment', text: 'Case #CRM-441 assigned to Mike Chen', time: '2 hours ago', icon: Users },
              { type: 'message', text: 'New message in case #CRM-440', time: '3 hours ago', icon: TrendingUp }
            ].map((activity, index) => {
              const IconComponent = activity.icon;
              return (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-8 h-8 rounded-full bg-[#f3f3f5] border border-[#cbcdce] flex items-center justify-center mt-0.5">
                    <IconComponent className="h-4 w-4 text-[#625f66]" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-[#1c1b1d]">{activity.text}</p>
                    <p className="text-xs text-[#989a9c]">{activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}