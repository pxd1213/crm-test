import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Avatar, AvatarFallback } from './ui/avatar';
import { MessageCircle, Send, Search, Paperclip, MoreVertical } from 'lucide-react';

interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: string;
  isOwner: boolean;
  caseId?: string;
}

interface Conversation {
  id: string;
  caseId: string;
  caseTitle: string;
  participants: string[];
  lastMessage: Message;
  unreadCount: number;
  messages: Message[];
}

interface MessagingInterfaceProps {
  unreadCount: number;
  onMessageRead: () => void;
}

const mockConversations: Conversation[] = [
  {
    id: 'conv-1',
    caseId: 'CRM-445',
    caseTitle: 'Login Issues with Mobile App',
    participants: ['John Doe', 'Current User'],
    unreadCount: 2,
    lastMessage: {
      id: 'msg-1',
      sender: 'John Doe',
      content: 'Any updates on the mobile login issue?',
      timestamp: '2025-06-11T11:30:00Z',
      isOwner: false
    },
    messages: [
      {
        id: 'msg-1',
        sender: 'John Doe',
        content: 'I\'m experiencing login issues with the mobile app. It keeps showing "Invalid credentials" even with correct login details.',
        timestamp: '2025-06-11T10:30:00Z',
        isOwner: true,
        caseId: 'CRM-445'
      },
      {
        id: 'msg-2',
        sender: 'Current User',
        content: 'Thank you for reporting this issue. I\'m looking into it now. Can you tell me which device and OS version you\'re using?',
        timestamp: '2025-06-11T10:35:00Z',
        isOwner: false,
        caseId: 'CRM-445'
      },
      {
        id: 'msg-3',
        sender: 'John Doe',
        content: 'I\'m using an iPhone 14 Pro with iOS 17.2.',
        timestamp: '2025-06-11T10:40:00Z',
        isOwner: true,
        caseId: 'CRM-445'
      },
      {
        id: 'msg-4',
        sender: 'John Doe',
        content: 'Any updates on the mobile login issue?',
        timestamp: '2025-06-11T11:30:00Z',
        isOwner: true,
        caseId: 'CRM-445'
      }
    ]
  },
  {
    id: 'conv-2',
    caseId: 'CRM-444',
    caseTitle: 'Payment Processing Error',
    participants: ['Jane Smith', 'Sarah Johnson'],
    unreadCount: 1,
    lastMessage: {
      id: 'msg-5',
      sender: 'Jane Smith',
      content: 'The payment issue is still occurring',
      timestamp: '2025-06-11T10:15:00Z',
      isOwner: false
    },
    messages: [
      {
        id: 'msg-5',
        sender: 'Jane Smith',
        content: 'Our customers are still experiencing payment failures. This is becoming critical.',
        timestamp: '2025-06-11T09:15:00Z',
        isOwner: true,
        caseId: 'CRM-444'
      },
      {
        id: 'msg-6',
        sender: 'Sarah Johnson',
        content: 'I\'ve contacted our payment provider and they\'re investigating. I\'ll keep you updated every hour.',
        timestamp: '2025-06-11T09:45:00Z',
        isOwner: false,
        caseId: 'CRM-444'
      },
      {
        id: 'msg-7',
        sender: 'Jane Smith',
        content: 'The payment issue is still occurring',
        timestamp: '2025-06-11T10:15:00Z',
        isOwner: true,
        caseId: 'CRM-444'
      }
    ]
  }
];

export function MessagingInterface({ unreadCount, onMessageRead }: MessagingInterfaceProps) {
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(mockConversations[0]);
  const [searchTerm, setSearchTerm] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [conversations, setConversations] = useState(mockConversations);

  const filteredConversations = conversations.filter(conv =>
    conv.caseTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
    conv.caseId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedConversation) return;

    const message: Message = {
      id: `msg-${Date.now()}`,
      sender: 'Current User',
      content: newMessage,
      timestamp: new Date().toISOString(),
      isOwner: false,
      caseId: selectedConversation.caseId
    };

    const updatedConversations = conversations.map(conv => {
      if (conv.id === selectedConversation.id) {
        return {
          ...conv,
          messages: [...conv.messages, message],
          lastMessage: message
        };
      }
      return conv;
    });

    setConversations(updatedConversations);
    setSelectedConversation({
      ...selectedConversation,
      messages: [...selectedConversation.messages, message],
      lastMessage: message
    });
    setNewMessage('');
  };

  const handleConversationSelect = (conversation: Conversation) => {
    setSelectedConversation(conversation);
    if (conversation.unreadCount > 0) {
      onMessageRead();
      const updatedConversations = conversations.map(conv =>
        conv.id === conversation.id ? { ...conv, unreadCount: 0 } : conv
      );
      setConversations(updatedConversations);
    }
  };

  return (
    <div className="flex h-[600px] bg-[#f8f8f8] p-6">
      <div className="flex h-full bg-white border border-[#cbcdce] rounded-lg overflow-hidden w-full">
        {/* Conversations List */}
        <div className="w-1/3 border-r border-[#cbcdce] bg-white">
          <div className="p-4 border-b border-[#cbcdce]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[#989a9c]" />
              <Input
                placeholder="Search conversations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white border-[#cbcdce] text-[#1c1b1d]"
              />
            </div>
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-2">
              {filteredConversations.map((conversation) => (
                <div
                  key={conversation.id}
                  className={`p-3 rounded-lg cursor-pointer hover:bg-[#f3f3f5] transition-colors ${
                    selectedConversation?.id === conversation.id ? 'bg-[#f3f3f5]' : ''
                  }`}
                  onClick={() => handleConversationSelect(conversation)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <p className="font-medium text-sm truncate text-[#625f66]">{conversation.caseTitle}</p>
                        {conversation.unreadCount > 0 && (
                          <Badge className="h-5 w-5 p-0 flex items-center justify-center text-xs bg-[#58a7af] text-white border-0">
                            {conversation.unreadCount}
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-[#989a9c] mb-1">{conversation.caseId}</p>
                      <p className="text-sm text-[#989a9c] truncate">
                        {conversation.lastMessage.content}
                      </p>
                      <p className="text-xs text-[#989a9c] mt-1">
                        {new Date(conversation.lastMessage.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {selectedConversation ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-[#cbcdce] bg-white">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-[#625f66]">{selectedConversation.caseTitle}</h3>
                    <p className="text-sm text-[#989a9c]">
                      Case {selectedConversation.caseId} • {selectedConversation.participants.join(', ')}
                    </p>
                  </div>
                  <Button variant="ghost" size="sm" className="text-[#989a9c] hover:text-[#625f66]">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 p-4 bg-[#f8f8f8]">
                <div className="space-y-4">
                  {selectedConversation.messages.map((message, index) => (
                    <div key={message.id}>
                      {index === 0 || new Date(message.timestamp).toDateString() !== new Date(selectedConversation.messages[index - 1].timestamp).toDateString() && (
                        <div className="flex justify-center my-4">
                          <span className="text-xs text-[#989a9c] bg-white px-2 py-1 rounded border border-[#cbcdce]">
                            {new Date(message.timestamp).toDateString()}
                          </span>
                        </div>
                      )}
                      <div className={`flex ${message.isOwner ? 'justify-end' : 'justify-start'}`}>
                        <div className={`flex items-start space-x-2 max-w-xs lg:max-w-md ${message.isOwner ? 'flex-row-reverse space-x-reverse' : ''}`}>
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="text-xs bg-[#989a9c] text-white">
                              {message.sender.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className={`rounded-lg p-3 border ${
                            message.isOwner 
                              ? 'bg-[#58a7af] text-white border-[#58a7af]' 
                              : 'bg-white border-[#cbcdce] text-[#1c1b1d]'
                          }`}>
                            <p className="text-sm">{message.content}</p>
                            <p className={`text-xs mt-1 ${
                              message.isOwner 
                                ? 'text-white/70' 
                                : 'text-[#989a9c]'
                            }`}>
                              {new Date(message.timestamp).toLocaleTimeString([], { 
                                hour: '2-digit', 
                                minute: '2-digit' 
                              })}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {/* Message Input */}
              <div className="p-4 border-t border-[#cbcdce] bg-white">
                <div className="flex items-end space-x-2">
                  <div className="flex-1">
                    <Textarea
                      placeholder="Type your message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      className="min-h-[40px] max-h-32 resize-none bg-white border-[#cbcdce] text-[#1c1b1d]"
                    />
                  </div>
                  <div className="flex space-x-1">
                    <Button variant="ghost" size="sm" className="text-[#989a9c] hover:text-[#625f66]">
                      <Paperclip className="h-4 w-4" />
                    </Button>
                    <Button 
                      onClick={handleSendMessage} 
                      size="sm" 
                      disabled={!newMessage.trim()}
                      className="bg-[#58a7af] hover:bg-[#4a9099] text-white border-0"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center bg-[#f8f8f8]">
              <div className="text-center">
                <MessageCircle className="h-12 w-12 text-[#989a9c] mx-auto mb-4" />
                <h3 className="font-medium mb-2 text-[#625f66]">Select a conversation</h3>
                <p className="text-sm text-[#989a9c]">
                  Choose a case conversation to start messaging
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}