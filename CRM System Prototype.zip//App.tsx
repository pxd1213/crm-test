import React, { useState } from 'react';
import { Sidebar, SidebarContent, SidebarProvider, SidebarTrigger } from './components/ui/sidebar';
import { Button } from './components/ui/button';
import { Dashboard } from './components/Dashboard';
import { CaseManagement } from './components/CaseManagement';
import { MessagingInterface } from './components/MessagingInterface';
import { SearchFilter } from './components/SearchFilter';
import { Home, FileText, MessageCircle, Search, Bell, HelpCircle, Files, User, ChevronDown, CheckCircle } from 'lucide-react';
import { Badge } from './components/ui/badge';

type ViewType = 'dashboard' | 'cases' | 'messages' | 'search';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [unreadMessages, setUnreadMessages] = useState(2);

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'cases':
        return <CaseManagement />;
      case 'messages':
        return <MessagingInterface unreadCount={unreadMessages} onMessageRead={() => setUnreadMessages(prev => Math.max(0, prev - 1))} />;
      case 'search':
        return <SearchFilter />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-[#f8f8f8]">
        <Sidebar className="border-r border-[#cbcdce]">
          <SidebarContent>
            <div className="p-4 border-b border-[#cbcdce]">
              <div className="flex items-center gap-2">
                <div className="w-5 h-4 relative">
                  <div className="absolute inset-0 bg-[#58a7af] rounded-sm"></div>
                  <div className="absolute top-1 left-1 right-1 bottom-1 bg-white rounded-sm"></div>
                </div>
                <div className="w-px h-7 bg-[#1c1b1d]"></div>
                <span className="text-[#1c1b1d] font-normal text-sm tracking-wide">CRM SYSTEM</span>
              </div>
              <div className="mt-1">
                <span className="text-[10px] text-[#1c1b1d] font-normal tracking-wider">CUSTOMER SUPPORT</span>
              </div>
            </div>
            <nav className="flex-1 p-4 space-y-1">
              <Button
                variant={currentView === 'dashboard' ? 'default' : 'ghost'}
                className="w-full justify-start h-9 bg-transparent hover:bg-[#f3f3f5] text-[#625f66] data-[state=open]:bg-[#58a7af] data-[state=open]:text-white"
                style={{ 
                  backgroundColor: currentView === 'dashboard' ? '#58a7af' : 'transparent',
                  color: currentView === 'dashboard' ? 'white' : '#625f66'
                }}
                onClick={() => setCurrentView('dashboard')}
              >
                <Home className="mr-3 h-4 w-4" />
                <span className="font-normal text-sm">Dashboard</span>
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start h-9 bg-transparent hover:bg-[#f3f3f5] text-[#625f66]"
                style={{ 
                  backgroundColor: currentView === 'cases' ? '#58a7af' : 'transparent',
                  color: currentView === 'cases' ? 'white' : '#625f66'
                }}
                onClick={() => setCurrentView('cases')}
              >
                <FileText className="mr-3 h-4 w-4" />
                <span className="font-normal text-sm">Cases</span>
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start h-9 bg-transparent hover:bg-[#f3f3f5] text-[#625f66] relative"
                style={{ 
                  backgroundColor: currentView === 'messages' ? '#58a7af' : 'transparent',
                  color: currentView === 'messages' ? 'white' : '#625f66'
                }}
                onClick={() => setCurrentView('messages')}
              >
                <MessageCircle className="mr-3 h-4 w-4" />
                <span className="font-normal text-sm">Messages</span>
                {unreadMessages > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="ml-auto h-5 w-5 p-0 flex items-center justify-center text-xs bg-[#58a7af] text-white border-0 font-medium"
                  >
                    {unreadMessages}
                  </Badge>
                )}
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start h-9 bg-transparent hover:bg-[#f3f3f5] text-[#625f66]"
                style={{ 
                  backgroundColor: currentView === 'search' ? '#58a7af' : 'transparent',
                  color: currentView === 'search' ? 'white' : '#625f66'
                }}
                onClick={() => setCurrentView('search')}
              >
                <Search className="mr-3 h-4 w-4" />
                <span className="font-normal text-sm">Search & Filter</span>
              </Button>
            </nav>
          </SidebarContent>
        </Sidebar>
        
        <div className="flex-1 flex flex-col">
          {/* Main Header */}
          <header className="bg-white border-b border-[#cbcdce] shadow-sm">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-6">
                {/* Logo and Title */}
                <div className="flex items-center gap-2">
                  <SidebarTrigger className="text-[#625f66]" />
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-4 relative">
                      <div className="absolute inset-0 bg-[#58a7af] rounded-sm"></div>
                      <div className="absolute top-1 left-1 right-1 bottom-1 bg-white rounded-sm"></div>
                    </div>
                    <div className="w-px h-7 bg-[#1c1b1d]"></div>
                    <span className="text-[#1c1b1d] font-normal text-sm tracking-wide">CRM SYSTEM</span>
                  </div>
                </div>

                {/* System Status */}
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-6 bg-[#4d8f1e] rounded flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <div className="text-[#4d8f1e] font-bold text-sm">SYSTEM</div>
                      <div className="text-[#4d8f1e] font-bold text-sm">OPERATIONAL</div>
                    </div>
                  </div>
                  <div className="w-0.5 h-8 bg-[#4d8f1e]"></div>
                  <div>
                    <div className="text-[#1c1b1d] font-bold text-sm">All Services Running Normally</div>
                    <div className="text-[#1c1b1d] font-normal text-sm">Last updated: Just now</div>
                  </div>
                </div>
              </div>

              {/* Header Actions */}
              <div className="flex items-center gap-2">
                {/* Notifications */}
                <div className="relative">
                  <Button variant="ghost" size="sm" className="text-[#989a9c] hover:text-[#625f66] p-2">
                    <Bell className="h-5 w-5" />
                  </Button>
                  <div className="absolute -top-1 -right-1 w-5 h-5 bg-[#58a7af] rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-medium">3</span>
                  </div>
                </div>

                <div className="w-0.5 h-8 bg-[#ddddde]"></div>

                {/* File Manager */}
                <Button variant="ghost" size="sm" className="text-[#989a9c] hover:text-[#625f66] p-2">
                  <Files className="h-5 w-5" />
                </Button>

                <div className="w-0.5 h-8 bg-[#ddddde]"></div>

                {/* Help Button */}
                <div className="relative">
                  <Button variant="ghost" size="sm" className="text-[#989a9c] hover:text-[#625f66] p-2">
                    <HelpCircle className="h-5 w-5" />
                  </Button>
                  <div className="absolute -top-1 -right-1 bg-[#ff6515] text-white text-xs px-2 py-0.5 rounded font-medium">
                    HELP
                  </div>
                </div>

                <div className="w-0.5 h-8 bg-[#ddddde]"></div>

                {/* User Info */}
                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <div className="text-[#56535b] text-xs font-normal">Support Manager</div>
                    <div className="text-[#56535b] text-sm font-black">ACME CORPORATION</div>
                  </div>
                  <User className="h-3 w-3 text-[#4d8f1e]" />
                  <ChevronDown className="h-3 w-3 text-[#989a9c] rotate-180" />
                </div>
              </div>
            </div>
          </header>

          {/* Navigation Tabs */}
          <div className="bg-white border-b border-[#cbcdce] shadow-sm">
            <div className="flex items-center justify-start px-6 pb-3">
              <nav className="flex gap-8">
                <button 
                  className={`flex items-center gap-1.5 py-2 text-sm font-normal ${
                    currentView === 'dashboard' ? 'text-[#625f66]' : 'text-[#625f66]'
                  }`}
                  onClick={() => setCurrentView('dashboard')}
                >
                  Dashboard
                  {currentView === 'dashboard' && <ChevronDown className="h-3 w-3 rotate-180" />}
                </button>
                <button className="flex items-center gap-1.5 py-2 text-sm font-normal text-[#625f66]">
                  <span className="font-medium">Case Management</span>
                  <span className="text-[#b2b1b3] text-xs">Active Cases</span>
                  <ChevronDown className="h-3 w-3 rotate-180" />
                </button>
                <button className="flex items-center gap-1.5 py-2 text-sm font-normal text-[#625f66]">
                  <span className="font-medium">Customer Service</span>
                  <span className="text-[#b2b1b3] text-xs">Support</span>
                  <ChevronDown className="h-3 w-3 rotate-180" />
                </button>
                <button className="py-2 text-sm font-normal text-[#625f66]">Reports</button>
                <button className="flex items-center gap-1.5 py-2 text-sm font-normal text-[#625f66]">
                  Settings & Admin
                  <ChevronDown className="h-3 w-3" />
                </button>
                <button className="py-2 text-sm font-normal text-[#625f66]">User Management</button>
              </nav>
            </div>
          </div>
          
          <main className="flex-1 overflow-auto bg-[#f8f8f8]">
            {renderContent()}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}