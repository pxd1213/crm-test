import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { Plus, Eye, Edit, MessageCircle, Paperclip, Clock, User } from 'lucide-react';

interface CaseData {
  id: string;
  title: string;
  description: string;
  status: 'New' | 'In Progress' | 'Resolved' | 'Closed';
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  assignedTo: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  messages: Array<{
    id: string;
    sender: string;
    content: string;
    timestamp: string;
  }>;
}

const mockCases: CaseData[] = [
  {
    id: 'CRM-445',
    title: 'Login Issues with Mobile App',
    description: 'Users reporting difficulty logging into the mobile application.',
    status: 'New',
    priority: 'High',
    assignedTo: 'Unassigned',
    createdBy: 'John Doe',
    createdAt: '2025-06-11T10:30:00Z',
    updatedAt: '2025-06-11T10:30:00Z',
    messages: [
      {
        id: '1',
        sender: 'John Doe',
        content: 'Initial report: Users cannot log in via mobile app since this morning.',
        timestamp: '2025-06-11T10:30:00Z'
      }
    ]
  },
  {
    id: 'CRM-444',
    title: 'Payment Processing Error',
    description: 'Credit card transactions failing intermittently.',
    status: 'In Progress',
    priority: 'Critical',
    assignedTo: 'Sarah Johnson',
    createdBy: 'Jane Smith',
    createdAt: '2025-06-10T14:15:00Z',
    updatedAt: '2025-06-11T09:45:00Z',
    messages: [
      {
        id: '1',
        sender: 'Jane Smith',
        content: 'Payment gateway returning error code 500 for credit card transactions.',
        timestamp: '2025-06-10T14:15:00Z'
      },
      {
        id: '2',
        sender: 'Sarah Johnson',
        content: 'Investigating the issue with payment provider. Will update shortly.',
        timestamp: '2025-06-11T09:45:00Z'
      }
    ]
  },
  {
    id: 'CRM-443',
    title: 'Data Export Feature Request',
    description: 'Customer requesting ability to export their data in CSV format.',
    status: 'In Progress',
    priority: 'Medium',
    assignedTo: 'Mike Chen',
    createdBy: 'Admin',
    createdAt: '2025-06-09T11:20:00Z',
    updatedAt: '2025-06-10T16:30:00Z',
    messages: [
      {
        id: '1',
        sender: 'Admin',
        content: 'Customer account #12345 requesting CSV export functionality.',
        timestamp: '2025-06-09T11:20:00Z'
      },
      {
        id: '2',
        sender: 'Mike Chen',
        content: 'Working on implementing the export feature. ETA: 2 days.',
        timestamp: '2025-06-10T16:30:00Z'
      }
    ]
  }
];

export function CaseManagement() {
  const [selectedCase, setSelectedCase] = useState<CaseData | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [cases, setCases] = useState<CaseData[]>(mockCases);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New': return 'bg-[#58a7af] text-white border-[#58a7af]';
      case 'In Progress': return 'bg-[#ff6515] text-white border-[#ff6515]';
      case 'Resolved': return 'bg-[#4d8f1e] text-white border-[#4d8f1e]';
      case 'Closed': return 'bg-[#989a9c] text-white border-[#989a9c]';
      default: return 'bg-[#989a9c] text-white border-[#989a9c]';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-500 text-white border-red-500';
      case 'High': return 'bg-orange-500 text-white border-orange-500';
      case 'Medium': return 'bg-yellow-500 text-white border-yellow-500';
      case 'Low': return 'bg-green-500 text-white border-green-500';
      default: return 'bg-[#989a9c] text-white border-[#989a9c]';
    }
  };

  const filteredCases = statusFilter === 'all' 
    ? cases 
    : cases.filter(case_ => case_.status.toLowerCase() === statusFilter);

  const handleCreateCase = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const newCase: CaseData = {
      id: `CRM-${446 + cases.length}`,
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      status: 'New',
      priority: formData.get('priority') as CaseData['priority'],
      assignedTo: formData.get('assignedTo') as string || 'Unassigned',
      createdBy: 'Current User',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: []
    };
    setCases([newCase, ...cases]);
    setIsCreateOpen(false);
  };

  return (
    <div className="p-6 bg-[#f8f8f8] min-h-full">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-4">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40 bg-white border-[#cbcdce] text-[#625f66]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent className="bg-white border-[#cbcdce]">
              <SelectItem value="all">All Cases</SelectItem>
              <SelectItem value="new">New</SelectItem>
              <SelectItem value="in progress">In Progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#58a7af] hover:bg-[#4a9099] text-white border-0 font-medium">
              <Plus className="mr-2 h-4 w-4" />
              New Case
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl bg-white border-[#cbcdce]">
            <DialogHeader>
              <DialogTitle className="text-[#625f66] font-bold">Create New Case</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateCase} className="space-y-4">
              <div>
                <Label htmlFor="title" className="text-[#625f66] font-medium">Title</Label>
                <Input id="title" name="title" required className="bg-white border-[#cbcdce] text-[#1c1b1d]" />
              </div>
              <div>
                <Label htmlFor="description" className="text-[#625f66] font-medium">Description</Label>
                <Textarea id="description" name="description" required className="bg-white border-[#cbcdce] text-[#1c1b1d]" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="priority" className="text-[#625f66] font-medium">Priority</Label>
                  <Select name="priority" required>
                    <SelectTrigger className="bg-white border-[#cbcdce] text-[#625f66]">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#cbcdce]">
                      <SelectItem value="Low">Low</SelectItem>
                      <SelectItem value="Medium">Medium</SelectItem>
                      <SelectItem value="High">High</SelectItem>
                      <SelectItem value="Critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="assignedTo" className="text-[#625f66] font-medium">Assign To</Label>
                  <Select name="assignedTo">
                    <SelectTrigger className="bg-white border-[#cbcdce] text-[#625f66]">
                      <SelectValue placeholder="Select operator" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-[#cbcdce]">
                      <SelectItem value="Sarah Johnson">Sarah Johnson</SelectItem>
                      <SelectItem value="Mike Chen">Mike Chen</SelectItem>
                      <SelectItem value="Emma Davis">Emma Davis</SelectItem>
                      <SelectItem value="Alex Rodriguez">Alex Rodriguez</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)} className="border-[#cbcdce] text-[#625f66]">
                  Cancel
                </Button>
                <Button type="submit" className="bg-[#58a7af] hover:bg-[#4a9099] text-white border-0">Create Case</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {selectedCase ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <Button variant="outline" onClick={() => setSelectedCase(null)} className="border-[#cbcdce] text-[#625f66] bg-white">
              ← Back to Cases
            </Button>
            <Button variant="outline" className="border-[#cbcdce] text-[#625f66] bg-white">
              <Edit className="mr-2 h-4 w-4" />
              Edit Case
            </Button>
          </div>

          <Card className="bg-white border-[#cbcdce]">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl text-[#625f66] font-bold">{selectedCase.title}</CardTitle>
                  <p className="text-sm text-[#989a9c] mt-1">Case ID: {selectedCase.id}</p>
                </div>
                <div className="flex space-x-2">
                  <Badge className={getPriorityColor(selectedCase.priority)}>
                    {selectedCase.priority}
                  </Badge>
                  <Badge className={getStatusColor(selectedCase.status)}>
                    {selectedCase.status}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="bg-[#f3f3f5] border-[#cbcdce]">
                  <TabsTrigger value="details" className="text-[#625f66] data-[state=active]:bg-white data-[state=active]:text-[#58a7af]">Details</TabsTrigger>
                  <TabsTrigger value="messages" className="text-[#625f66] data-[state=active]:bg-white data-[state=active]:text-[#58a7af]">Messages ({selectedCase.messages.length})</TabsTrigger>
                  <TabsTrigger value="history" className="text-[#625f66] data-[state=active]:bg-white data-[state=active]:text-[#58a7af]">History</TabsTrigger>
                </TabsList>
                
                <TabsContent value="details" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-[#625f66] font-medium">Created By</Label>
                      <p className="text-sm text-[#1c1b1d]">{selectedCase.createdBy}</p>
                    </div>
                    <div>
                      <Label className="text-[#625f66] font-medium">Assigned To</Label>
                      <p className="text-sm text-[#1c1b1d]">{selectedCase.assignedTo}</p>
                    </div>
                    <div>
                      <Label className="text-[#625f66] font-medium">Created At</Label>
                      <p className="text-sm text-[#1c1b1d]">{new Date(selectedCase.createdAt).toLocaleString()}</p>
                    </div>
                    <div>
                      <Label className="text-[#625f66] font-medium">Last Updated</Label>
                      <p className="text-sm text-[#1c1b1d]">{new Date(selectedCase.updatedAt).toLocaleString()}</p>
                    </div>
                  </div>
                  <Separator className="bg-[#cbcdce]" />
                  <div>
                    <Label className="text-[#625f66] font-medium">Description</Label>
                    <p className="text-sm mt-1 text-[#1c1b1d]">{selectedCase.description}</p>
                  </div>
                </TabsContent>
                
                <TabsContent value="messages" className="space-y-4">
                  <div className="space-y-4">
                    {selectedCase.messages.map((message) => (
                      <div key={message.id} className="border border-[#cbcdce] rounded-lg p-4 bg-white">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4 text-[#989a9c]" />
                            <span className="font-medium text-[#625f66]">{message.sender}</span>
                          </div>
                          <span className="text-sm text-[#989a9c]">
                            {new Date(message.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-sm text-[#1c1b1d]">{message.content}</p>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-[#cbcdce] pt-4">
                    <Textarea placeholder="Type your message..." className="bg-white border-[#cbcdce] text-[#1c1b1d]" />
                    <div className="flex justify-between items-center mt-2">
                      <Button variant="outline" size="sm" className="border-[#cbcdce] text-[#625f66] bg-white">
                        <Paperclip className="h-4 w-4 mr-1" />
                        Attach
                      </Button>
                      <Button size="sm" className="bg-[#58a7af] hover:bg-[#4a9099] text-white border-0">Send Message</Button>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="history">
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <Clock className="h-4 w-4 text-[#989a9c] mt-0.5" />
                      <div>
                        <p className="text-sm text-[#1c1b1d]">Case created by {selectedCase.createdBy}</p>
                        <p className="text-xs text-[#989a9c]">{new Date(selectedCase.createdAt).toLocaleString()}</p>
                      </div>
                    </div>
                    {selectedCase.assignedTo !== 'Unassigned' && (
                      <div className="flex items-start space-x-3">
                        <User className="h-4 w-4 text-[#989a9c] mt-0.5" />
                        <div>
                          <p className="text-sm text-[#1c1b1d]">Assigned to {selectedCase.assignedTo}</p>
                          <p className="text-xs text-[#989a9c]">{new Date(selectedCase.updatedAt).toLocaleString()}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card className="bg-white border-[#cbcdce]">
          <CardHeader>
            <CardTitle className="text-[#625f66] font-bold">Cases ({filteredCases.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow className="border-[#cbcdce]">
                  <TableHead className="text-[#625f66] font-medium">Case ID</TableHead>
                  <TableHead className="text-[#625f66] font-medium">Title</TableHead>
                  <TableHead className="text-[#625f66] font-medium">Status</TableHead>
                  <TableHead className="text-[#625f66] font-medium">Priority</TableHead>
                  <TableHead className="text-[#625f66] font-medium">Assigned To</TableHead>
                  <TableHead className="text-[#625f66] font-medium">Created</TableHead>
                  <TableHead className="text-[#625f66] font-medium">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCases.map((case_) => (
                  <TableRow key={case_.id} className="border-[#cbcdce] hover:bg-[#f8f8f8]">
                    <TableCell className="font-mono text-[#1c1b1d]">{case_.id}</TableCell>
                    <TableCell className="max-w-xs truncate text-[#1c1b1d]">{case_.title}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(case_.status)}>
                        {case_.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getPriorityColor(case_.priority)}>
                        {case_.priority}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-[#1c1b1d]">{case_.assignedTo}</TableCell>
                    <TableCell className="text-[#1c1b1d]">{new Date(case_.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => setSelectedCase(case_)} className="text-[#625f66] hover:text-[#58a7af] hover:bg-[#f3f3f5]">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-[#625f66] hover:text-[#58a7af] hover:bg-[#f3f3f5]">
                          <MessageCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}